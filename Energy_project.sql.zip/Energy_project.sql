CREATE DATABASE ENERGYDB2;
USE ENERGYDB2;

-- 1. country table
CREATE TABLE country (
    CID VARCHAR(10) PRIMARY KEY,
    Country VARCHAR(100) UNIQUE
);

SELECT * FROM COUNTRY;

-- 2. emission_3 table
CREATE TABLE emission_3 (
    country VARCHAR(100),
    energy_type VARCHAR(50),
    year INT,
    emission INT,
    per_capita_emission DOUBLE,
    FOREIGN KEY (country) REFERENCES country(Country)
);

SELECT * FROM EMISSION_3;


-- 3. population table
CREATE TABLE population (
    countries VARCHAR(100),
    year INT,
    Value DOUBLE,
    FOREIGN KEY (countries) REFERENCES country(Country)
);

SELECT * FROM POPULATION;

-- 4. production table
CREATE TABLE production (
    country VARCHAR(100),
    energy VARCHAR(50),
    year INT,
    production INT,
    FOREIGN KEY (country) REFERENCES country(Country)
);


SELECT * FROM PRODUCTION;

-- 5. gdp_3 table
CREATE TABLE gdp_3 (
    Country VARCHAR(100),
    year INT,
    Value DOUBLE,
    FOREIGN KEY (Country) REFERENCES country(Country)
);

SELECT * FROM GDP_3;

-- 6. consumption table
CREATE TABLE consumption (
    country VARCHAR(100),
    energy VARCHAR(50),
    year INT,
    consumption INT,
    FOREIGN KEY (country) REFERENCES country(Country)
);

SELECT * FROM CONSUMPTION;

-- What is the total emission per country for the most recent year available?
select country, max(year) max_year, sum(per_capita_emission) as tot from emission_3 group by country order by max_year desc;

-- What are the top 5 countries by GDP in the most recent year?
select country, value as gdp from gdp_3 where year =(select max(year) from gdp_3) order by gdp desc limit 5;

-- Compare energy production and consumption by country and year. 
select a.country, a.year, a.production, b.consumption
from production as a
inner join consumption as b
on a.country=b.country and a.year= b.year;

-- Which energy types contribute most to emissions across all countries?
select energy_type, sum(per_capita_emission) as tot_emission from emission_3 group by energy_type order by tot_emission desc;

--  Trend Analysis Over Time
-- How have global emissions changed year over year?
select year, sum(per_capita_emission) as tot_emission from emission_3 group by year order by tot_emission;

-- What is the trend in GDP for each country over the given years?
select country, year, sum(value) as tot_gdp from gdp_3 group by country, year order by country, year;

-- How has population growth affected total emissions in each country?
select a.countries, a.year, a.value, b.per_capita_emission, (a.value * b.per_capita_emission) as tot_emission
from population as a
inner join emission_3 as b
on a.countries=b.country and a.year= b.year
order by a.countries, a.year;

-- Has energy consumption increased or decreased over the years for major economies?
select a.country, a.year, sum(a.consumption) as tot_consumption from consumption as a
inner join
gdp_3 as b 
on a.country= b.country and a.year = b.year
group by a.country, a.year
order by tot_consumption desc;

-- What is the average yearly change in emissions per capita for each country?
select a.country, a.year, avg(per_capita_emission) as avg_emission from emission_3
as a inner join
gdp_3 as b 
on a.country = b.country and a.year=b.year
group by a.country, a.year
order by avg_emission;

with yearchange as (
    select
        country,
        year,
        per_capita_emission,
        lag(per_capita_emission, 1, 0) over (partition by country order by year) as previous_year_emission
    from
        emission_3
)
select
    country,
    avg(per_capita_emission - previous_year_emission) AS average_yearly_change
from
    yearchange
where
    previous_year_emission IS NOT NULL
group by
    country
order by
    country;

-- Ratio & Per Capita Analysis
-- What is the emission-to-GDP ratio for each country by year?
select a.country, a.year, (a.per_capita_emission/ b.value ) as gdp_ratio
from emission_3 as a 
inner join gdp_3 as b
on a.country = b.country and a.year = b.year
order by a.country, b.country;

-- What is the energy consumption per capita for each country over the last decade?
select a.country, a.year, (a.consumption/b.value) as consump_pp from consumption as a
inner join population as b
on a.country=b.countries and a.year=b.year where a.year >=(select max(year) from consumption) -9
order by consump_pp desc;

-- How does energy production per capita vary across countries?
select a.country, a.year, (a.production/b.value) as prod_pc from production as a
inner join gdp_3 as b
on a.country=b.country and a.year=b.year 
order by prod_pc desc ;

-- Which countries have the highest energy consumption relative to GDP?
select a.country, a.year, (a.consumption/ b.value) as energy_consump
from consumption as a 
inner join gdp_3 as b
on a.country=b.country and a.year = b.year
order by energy_consump desc limit 10;

-- What is the correlation between GDP growth and energy production growth?

with gdp_growth AS (
    select
        country,
        year,
        value AS gdp,
        (value - lag(value, 1) over (partition BY country order by year)) / lag(value, 1) over (partition BY country order by year) as gdp_growth_rate
    from
        gdp_3
),
Production_Growth as (
    select
        country,
        year,
        production,
        (production - lag(production, 1) over (partition by country order by year)) / lag(production, 1) over (partition by country order by year) as production_growth_rate
    from
        production
)
select
    g.country,
    g.year,
    g.gdp_growth_rate,
    p.production_growth_rate
from
    gdp_growth as g
inner join
    Production_Growth as p on g.country = p.country and g.year = p.year
where
    g.gdp_growth_rate is not null and p.production_growth_rate is not null
order by
    g.country, g.year;
    
-- What are the top 10 countries by population and how do their emissions compare?

create table maxpop as
select countries, year, value as pop
from population 
where(countries, year) in (select countries, max(year) from population group by countries) order by pop desc limit 10;


select * from maxpop;

select a.countries, a.year, a.pop, b.per_capita_emission as tot_emission
from maxpop as a
inner join
emission_3 as b
on a.countries=b.country and a.year=b.year
order by a.pop desc;

-- Which countries have improved (reduced) their per capita emissions the most over the last decade?
with lastdecade AS (
    select
        country,
        year,
        per_capita_emission
    from
        emission_3
    where
        year >= (select max(year) from emission_3) - 9
),
startendemissions as (
    select
        country,
        (select per_capita_emission from lastdecade where country = d.country order by year asc limit 1) as start_emission,
        (select per_capita_emission from lastdecade where country = d.country order by year desc limit 1) as end_emission
    from
        LastDecade AS d
    group by
        country
)
select
    country,
    (start_emission - end_emission) as emission_reduction
from
    StartEndEmissions
where
    (start_emission - end_emission) > 0
order BY
    emission_reduction desc
limit 10;
-- What is the global share (%) of emissions by country?

with CountryEmissions AS (
    select
        country,
        sum(per_capita_emission) AS country_total_emissions
    from
        emission_3
    group by
        country
),
GlobalEmissions as (
    select
        sum(country_total_emissions) AS global_total
    from
        CountryEmissions
)
select
    c.country,
    (c.country_total_emissions / g.global_total) * 100 as global_share_percentage
from
    CountryEmissions as c
cross JOIN
    GlobalEmissions as g
order by
    global_share_percentage desc;
    
    -- What is the global average GDP, emission, and population by year?

select
    p.year,
    avg(p.value) as avg_population,
    avg(e.per_capita_emission) as avg_emissions,
    avg(g.value) as avg_gdp
from
    population AS p
inner join
    emission_3 AS e ON p.year = e.year
inner join
    gdp_3 AS g ON p.year = g.yearßßßßßßß
group by
    p.year
order by
    p.year;